

import Table from './components/table';

function App() {
  return (
    <div >
      <Table/>
    </div>
  );
}

export default App;
