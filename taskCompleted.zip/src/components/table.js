import React from "react";
import "../styles/table.css";
import Popup from "reactjs-popup";

function Table() {
  const arr = [
    {
      id: 1,
      FirstName: "Astha ",
      LastName: "Sharma",
      Subjects: ["Maths", "physics", "chemistry"]
    },

    {
      id: 2,
      FirstName: "karshima ",
      LastName: "Sharma",
      Subjects: ["Maths", "physics", "chemistry", "Hindi", "sanskrit"]
    },
    {
      id: 3,
      FirstName: "samntha",
      LastName: "Sharma",
      Subjects: [
        "Maths",
        "physics",
        "chemistry",
        "sanskrit",
        "hindi",
        "history"
      ]
    }
  ];

  return (
    <div>
      <table style={{ border: "1px solid black" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Subjects</th>
          </tr>
        </thead>
        <tbody>
          {arr.map((items) => {
            return (
              <tr key={items.id}>
                <td>{items.id}</td>
                <td>{items.FirstName}</td>
                <td>{items.LastName}</td>
                <td>{items.Subjects[0]}</td>
                <Popup
                  trigger={<button className="Hover" style={{border: "none",backgroundColor: "white",fontSize: "26px"}}>...</button>}
                  position="right center"
                >
                  <div
                    className="hide"
                    style={{
                      height: "80px",
                      width: "200px",
                      overflow: "overlay"
                    }}
                  >
                    <ul>
                      {items.Subjects.map((items) => (
                        <li key={items.id}>{items}</li>
                      ))}
                    </ul>
                  </div>
                </Popup>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
export default Table;
