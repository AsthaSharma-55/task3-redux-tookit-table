import React,{useEffect, useState} from "react";
import { useSelector, useDispatch } from 'react-redux';
import { getUsers } from "../store/actions/usersaction";
import { useParams } from "react-router-dom";

const Users = () => {
    // const [data,setData]=useState()

    // const { users, loader } = useSelector((state) => state.users)
    // const params=useParams();
    // const{id}=params;
    // console.log(id)
    
    
    // console.log(users)        //destructuring
    // const dispatch = useDispatch();


    // useEffect(() => {
    //     dispatch(getUsers())
    // }, [])

    // useEffect(() => {
    //     setData()
    // }, [users])
     
    return (
        <div>
            {/* {data.params.users[id].name} */}
        </div>
    )
}
export default Users;